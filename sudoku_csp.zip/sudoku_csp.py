
import copy
import sys
from collections import deque


def read_board(filename: str) -> list[list[int]]:
    
    board = []
    with open(filename, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if len(line) != 9 or not line.isdigit():
                raise ValueError(f"Invalid board line: '{line}'")
            board.append([int(ch) for ch in line])
    if len(board) != 9:
        raise ValueError(f"Board must have 9 rows, got {len(board)}")
    return board
def print_board(board: list[list[int]], title: str = "") -> None:
  
    if title:
        print(f"\n{'='*37}")
        print(f"  {title}")
        print(f"{'='*37}")
    print("+-------+-------+-------+")
    for r in range(9):
        row_str = "| "
        for c in range(9):
            val = board[r][c]
            row_str += (str(val) if val != 0 else ".") + " "
            if c in (2, 5):
                row_str += "| "
        row_str += "|"
        print(row_str)
        if r in (2, 5):
            print("+-------+-------+-------+")
    print("+-------+-------+-------+")

def get_peers(row: int, col: int) -> set[tuple[int, int]]:
    peers = set()
    for c in range(9):
        if c != col:
            peers.add((row, c))

    for r in range(9):
        if r != row:
            peers.add((r, col))

    
    box_r, box_c = 3 * (row // 3), 3 * (col // 3)
    for r in range(box_r, box_r + 3):
        for c in range(box_c, box_c + 3):
            if (r, c) != (row, col):
                peers.add((r, c))

    return peers

PEERS: dict[tuple[int, int], set[tuple[int, int]]] = {
    (r, c): get_peers(r, c) for r in range(9) for c in range(9)
}


def board_to_domains(board: list[list[int]]) -> dict[tuple[int, int], set[int]]:
   
    domains: dict[tuple[int, int], set[int]] = {}
    for r in range(9):
        for c in range(9):
            if board[r][c] != 0:
                domains[(r, c)] = {board[r][c]}
            else:
                domains[(r, c)] = set(range(1, 10))
    return domains
def domains_to_board(domains: dict[tuple[int, int], set[int]]) -> list[list[int]]:
    """Convert domains back to a board (0 if a cell has more than one value)."""
    board = [[0] * 9 for _ in range(9)]
    for (r, c), vals in domains.items():
        if len(vals) == 1:
            board[r][c] = next(iter(vals))
    return board

def ac3(domains: dict[tuple[int, int], set[int]]) -> bool:
  
    queue: deque[tuple[tuple[int, int], tuple[int, int]]] = deque()
    for cell in domains:
        for peer in PEERS[cell]:
            queue.append((cell, peer))

    while queue:
        xi, xj = queue.popleft()

        if revise(domains, xi, xj):
            if len(domains[xi]) == 0:
                return False   
            for xk in PEERS[xi]:
                if xk != xj:
                    queue.append((xk, xi))

    return True


def revise(
    domains: dict[tuple[int, int], set[int]],
    xi: tuple[int, int],
    xj: tuple[int, int],
) -> bool:
   
    revised = False
   
    if len(domains[xj]) == 1:
        fixed_val = next(iter(domains[xj]))
        if fixed_val in domains[xi]:
            domains[xi].discard(fixed_val)
            revised = True
    return revised



def forward_check(
    domains: dict[tuple[int, int], set[int]],
    var: tuple[int, int],
    value: int,
) -> bool:
    
    for peer in PEERS[var]:
        domains[peer].discard(value)
        if len(domains[peer]) == 0:
            return False
    return True


def select_unassigned_variable(
    domains: dict[tuple[int, int], set[int]]
) -> tuple[int, int] | None:
   
    unassigned = [cell for cell, vals in domains.items() if len(vals) > 1]
    if not unassigned:
      
        return None
    
    return min(
        unassigned,
        key=lambda cell: (
            len(domains[cell]),
            -sum(1 for p in PEERS[cell] if len(domains[p]) > 1),  # degree tiebreak
        ),
    )


def order_domain_values(
    domains: dict[tuple[int, int], set[int]],
    var: tuple[int, int],
) -> list[int]:
  
    def count_constraints(val: int) -> int:
        return sum(1 for peer in PEERS[var] if val in domains[peer])

    return sorted(domains[var], key=count_constraints)


backtrack_calls = 0
backtrack_failures = 0


def backtrack(
    domains: dict[tuple[int, int], set[int]]
) -> dict[tuple[int, int], set[int]] | None:
   
    global backtrack_calls, backtrack_failures
    backtrack_calls += 1

   
    if all(len(vals) == 1 for vals in domains.values()):
        return domains

    var = select_unassigned_variable(domains)
    if var is None:
        return domains 

    
    for value in order_domain_values(domains, var):
       
        new_domains = copy.deepcopy(domains)
        new_domains[var] = {value}

        if forward_check(new_domains, var, value):
       
            if ac3(new_domains):
                result = backtrack(new_domains)
                if result is not None:
                    return result

        backtrack_failures += 1

    return None  



def solve(board: list[list[int]], puzzle_name: str) -> list[list[int]] | None:
   
    global backtrack_calls, backtrack_failures
    backtrack_calls = 0
    backtrack_failures = 0

    print(f"\n{'─'*37}")
    print(f"  Solving: {puzzle_name}")
    print(f"{'─'*37}")

    domains = board_to_domains(board)

    print("  Running AC-3 preprocessing...")
    if not ac3(domains):
        print("  AC-3 detected contradiction → no solution.")
        return None

   
    if all(len(v) == 1 for v in domains.values()):
        print("  AC-3 solved the puzzle without backtracking!")
        solved_board = domains_to_board(domains)
        return solved_board

    print("  AC-3 incomplete — starting backtracking search...")
    result = backtrack(domains)

    print(f"\n  BACKTRACK calls   : {backtrack_calls}")
    print(f"  BACKTRACK failures: {backtrack_failures}")

    if result is None:
        print("  No solution found.")
        return None

    return domains_to_board(result)



def main() -> None:
    puzzles = [
    (r"C:\Users\LENOVO\Downloads\aI_Asiignment5\easy.txt", "Easy Board"),
    (r"C:\Users\LENOVO\Downloads\aI_Asiignment5\medium.txt", "Medium Board"),
    (r"C:\Users\LENOVO\Downloads\aI_Asiignment5\hard.txt", "Hard Board"),
    (r"C:\Users\LENOVO\Downloads\aI_Asiignment5\veryhard.txt", "Very Hard Board"),
]

    stats: list[dict] = []

    for filename, label in puzzles:
        try:  
            board = read_board(filename)
        except FileNotFoundError:
            print(f"\n[SKIP] File not found: {filename}")
            continue
        except ValueError as e:
            print(f"\n[ERROR] {e}")
            continue

        print_board(board, f"Input — {label}")
        solution = solve(board, label)

        if solution:
            print_board(solution, f"Solution — {label}")
            stats.append({
                "puzzle": label,
                "calls": backtrack_calls,
                "failures": backtrack_failures,
            })
        else:
            print(f"  Could not solve {label}.")

    
    if stats:
        print(f"\n{'='*55}")
        print(f"  {'PUZZLE':<20} {'BT CALLS':>10} {'BT FAILURES':>12}")
        print(f"  {'─'*20} {'─'*10} {'─'*12}")
        for s in stats:
            print(f"  {s['puzzle']:<20} {s['calls']:>10} {s['failures']:>12}")
        print(f"{'='*55}")

if __name__ == "__main__":
    main()
